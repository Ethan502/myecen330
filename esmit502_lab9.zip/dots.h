#ifndef DOTS_H
#define DOTS_H

typedef struct {
  int x;
  int y;
  bool eaten;

} dot;

#endif